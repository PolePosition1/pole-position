# Components & Patterns

Specs are token-based so any build (app, landing page, Claude Design artifact,
social asset) comes out identical. All radii/space/color refer to `tokens.css`.

## Foundations
- **Grid:** 4px base unit. Spacing only from the scale (4 / 8 / 12 / 16 / 24 / 32 / 48 / 64).
- **Radius:** cards `lg` (16px) · buttons & inputs `md` (10px) · chips/pills `pill` · sheets `xl` (24px).
- **Elevation:** cards `elev-1`; modals/sheets `elev-2`; active CTA & winner state add `glow-purple`.
- **Default surface stack:** Lights Out (page) → Carbon (card) → Pit Wall (input/inset).

## Buttons
| Variant | Fill | Label | Hover | Use |
|---|---|---|---|---|
| Primary | `purple-500` | white, Inter 600, ≥16px | `purple-700` + `glow-purple` | Lock In, Make Picks |
| Gradient | `grad-pole` | white 700 | brightness 110% | Hero / single key CTA |
| Secondary | transparent, `1px line` border | `text-2` | bg `pit-wall` | Secondary actions |
| Ghost | none | `purple-200` | underline | Tertiary / inline |
| Danger | `red-500` | white | `red-700` | Destructive only |

Buttons are verbs. Min height 44px (touch). Pressed state = darker shade, no scale jump.

## Pick Card
The core object. A driver/outcome the user can select.
- Surface `carbon`, radius `lg`, border `1px line`.
- **Default:** border `line`, label `text-2`.
- **Selected:** border `purple-500` (2px), subtle `purple-900` fill, `glow-purple`.
- **Locked:** border `red-500`, a lock icon + "LOCKED" mono label; no longer tappable.
- **Model's pick badge:** a small `red-500` chip "MODEL" in the corner when showing what the model chose.
- Position marker (P1/P2/P3) in mono, top-left, `label` style.

## Lock-In State
When picks lock at quali close:
- The whole pick set gets a `red-500` top hairline + "GRID IS SET" mono banner.
- Animation (optional): the five-lights row goes out → screen settles. Lights-out moment.

## Leaderboard Row
- Mono tabular everywhere. Rank (mono 700) · name (Inter 600) · points (mono 700, right-aligned).
- **You:** row bg `purple-900`, left border `purple-500`.
- **Top 3:** rank number tinted — P1 `purple-400`, P2 `text`, P3 `amber-500`.
- Climbing indicator: small `green-400` ▲ / `red-400` ▼ with delta.

## Score / Result Chip
- Mono, pill radius. `+5` exact-slot in `green-500`; `+2` podium-hit in `green-400`; perfect-podium bonus in `purple-500` ("PERFECT PODIUM +5"); miss in `text-faint`.

## Countdown Timer ("Picks lock in")
- `data-xl` mono tabular. Under 1hr → digits `amber-500`. Under 5min → `red-500` + gentle pulse.

## "Called It" Stamp (the win moment)
- Saira 800, all caps "CALLED IT", purple→gradient, slight rotation, on a flash of `glow-purple`. This is the brand's signature celebration — reserve it for genuinely correct calls.

## Signature motifs (use as texture, sparingly)
- **Five-lights row:** five dots, used for loading, step progress, or as a divider. Lights "go out" (fade) on confirm.
- **Grid-slot angle / speed chevrons:** forward-leaning angles as section dividers or card corners. Never decorative clutter — one accent per view.

## Forms / Inputs
- Surface `pit-wall`, border `line`, radius `md`, text `text-2`, placeholder `text-muted`.
- Focus: border `purple-500` + `glow-purple`. Error: border `red-500`, helper `red-400`.

## States checklist (every interactive element ships with all five)
default · hover · focus · active/selected · disabled (`text-faint`, 40% opacity, no glow).
