# Pole Position — Brand & Design System

The source of truth for the Pole Position visual identity, voice, and design
tokens. Everything Pole Position ships — the app, landing pages, social assets,
merch, decks — references this repo so it stays on brand.

**Start here:** [`BRAND.md`](./BRAND.md) for the system, or
[`CLAUDE-DESIGN-BRIEF.md`](./CLAUDE-DESIGN-BRIEF.md) to feed straight into an AI agent.

```
.
├── BRAND.md                  ← master brand system overview
├── CLAUDE-DESIGN-BRIEF.md    ← paste-into-the-agent compact brief
├── brand/
│   ├── tokens.json           ← design tokens (source of truth)
│   ├── tokens.css            ← CSS custom properties
│   ├── tailwind.preset.js    ← Tailwind preset
│   ├── colors.md
│   ├── typography.md
│   ├── voice-and-tone.md
│   ├── logo.md
│   └── components.md
├── assets/   (logos · fonts · icons · social)
├── templates/
└── examples/
```

## How to use this with Claude Design

Claude Design doesn't auto-sync to a GitHub repo — so this repo is the
**source of truth + version history**, and you feed the brand *into* a session one
of three ways:

1. **Paste the brief (most reliable).** Open `CLAUDE-DESIGN-BRIEF.md`, copy the
   whole thing, paste it as your first message in Claude Design, then make your
   request: *"Using this brand, design the Pole Position picks screen."*

2. **Reference the raw URL.** Once pushed, give Claude the raw link and ask it to
   read it first:
   `https://raw.githubusercontent.com/PolePosition1/pole-position/main/CLAUDE-DESIGN-BRIEF.md`
   (raw links for any file: swap `github.com` → `raw.githubusercontent.com` and add `/main/`.)

3. **Drop the token files into a build.** For web artifacts/landing pages, paste
   `brand/tokens.css` (or wire up `tailwind.preset.js`) and everything inherits
   the palette, type, and spacing automatically.

**For consistency over time**, the brief also works as: a file in a Claude Project
(so every chat in that project is pre-loaded), or the seed for a `pole-position-brand`
Claude Skill.

## Keeping it in sync
`tokens.json` is the real source. If you change a color or font, update
`tokens.css` and `tailwind.preset.js` in the same commit and bump the version in
`tokens.json`. The three must never disagree.

## Status
**v1.0.0 — proposed identity.** Black + purple "timing screen" direction. If the
live app at polepositionapp.com already uses specific hex values, set them in
`tokens.json` / `tokens.css` and the whole system re-skins to match.

— Pole Position. Lights out. Lock in.
