# Logos
Drop logo files here. Recommended set once the mark exists:
- `pole-position-wordmark-white.svg`
- `pole-position-wordmark-purple.svg`
- `pole-position-monogram-gradient.svg`  (app icon source)
- `pole-position-lights.svg`             (five-lights motif)
Plus PNG exports at 1024 / 512 / 192 / 48 / 16 px for icons & favicons.
See ../../brand/logo.md for construction rules.
