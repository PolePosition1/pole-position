/* ============================================================
   POLE POSITION — Tailwind Preset
   v1.0.0  ·  Source of truth: brand/tokens.json
   ------------------------------------------------------------
   Usage (tailwind.config.js):
     module.exports = { presets: [require('./brand/tailwind.preset.js')] }
   Then use classes like: bg-pp-lights-out, text-pp-purple-500,
   font-display, rounded-pp-lg, shadow-pp-glow-purple
   ============================================================ */

module.exports = {
  theme: {
    extend: {
      colors: {
        pp: {
          'lights-out': '#0A0E17',
          carbon:       '#14181F',
          'pit-wall':   '#1E242E',
          line:         '#2A3340',
          purple: { 200:'#D9B8FF', 400:'#B47CFF', 500:'#9B2FFF', 700:'#7A1FCC', 900:'#3D0F66' },
          green:  { 400:'#5CFFA8', 500:'#00E676', 700:'#00B85E' },
          red:    { 400:'#FF6B78', 500:'#FF2436', 700:'#CC1424' },
          amber:  { 400:'#FFD24D', 500:'#FFB800', 700:'#CC9300' },
          blue:   { 500:'#2D7FFF' },
          text:   { DEFAULT:'#FFFFFF', 2:'#E8EAED', muted:'#9AA3AF', faint:'#5A626E' },
        },
      },
      fontFamily: {
        display: ['Saira', 'system-ui', 'sans-serif'],
        body:    ['Inter', 'system-ui', 'sans-serif'],
        mono:    ['JetBrains Mono', 'ui-monospace', 'monospace'],
      },
      backgroundImage: {
        'pp-pole':   'linear-gradient(135deg, #9B2FFF 0%, #2D7FFF 100%)',
        'pp-podium': 'linear-gradient(135deg, #FFB800 0%, #FF2436 100%)',
      },
      borderRadius: { 'pp-sm':'6px', 'pp-md':'10px', 'pp-lg':'16px', 'pp-xl':'24px' },
      boxShadow: {
        'pp-elev-1': '0 1px 2px rgba(0,0,0,0.40)',
        'pp-elev-2': '0 4px 12px rgba(0,0,0,0.50)',
        'pp-glow-purple': '0 0 24px rgba(155,47,255,0.35)',
        'pp-glow-green':  '0 0 20px rgba(0,230,118,0.30)',
      },
    },
  },
};
