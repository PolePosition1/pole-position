# Logo & Mark

> The actual logo files don't exist yet. This spec defines how the mark should be
> built so it's consistent the day it's drawn. You can hand this file straight to
> Claude Design and say "generate the Pole Position primary lockup from this spec."

## Concept
The mark should encode **one** of these motifs — pick one and commit:

1. **The five lights.** Five horizontal dots/bars (the F1 start gantry), with the
   brand purple as the "go." Instantly motorsport, instantly Pole Position.
2. **P1 monogram.** A geometric "P1" where the "1" doubles as the pole/grid-slot
   marker — front-row, position one.
3. **Grid-slot chevron.** A forward chevron / leading-edge angle (the box you
   start in on the grid), purple, implying first place and forward motion.

**Recommended primary:** the **P1 monogram** for the app icon (works tiny), with
the **five-lights** motif as a secondary/loading/brand texture.

## Construction rules
- **Wordmark:** "POLE POSITION" set in **Saira 800**, tracked tight, all caps.
  "POLE" and "POSITION" can stack or run inline. Optional purple accent on the
  "P" or a single grid-slot tick.
- **Geometry only.** No literal cars, helmets, flags-as-clipart, or driver/team
  references. The mark is abstract and ownable.
- **One-color first.** It must work in pure white on Lights Out before any color
  or gradient is added.

## Color treatments (priority order)
1. **White** on Lights Out `#0A0E17` — default.
2. **Purple `#9B2FFF`** on Lights Out — brand emphasis.
3. **Pole gradient** (`#9B2FFF → #2D7FFF`) — hero / app icon / merch only.
4. **Lights Out** on white — for light-background placements (rare).

## Clear space & sizing
- Clear space on all sides = the height of the "P" in the wordmark.
- Minimum sizes: wordmark **24px** tall on screen; app-icon monogram legible at **48×48px** down to a **16px** favicon.

## Misuse — never
- Don't recolor outside the four treatments above.
- Don't add drop shadows, bevels, or outlines to the mark.
- Don't stretch, condense, or rotate.
- Don't place on a busy photo without a Lights Out scrim behind it.
- Don't pair with driver/team logos or imagery.

## App icon
Monogram (P1) in **Pole gradient** on Lights Out, centered, with generous
padding. Test at 1024px and at 48px — if the "1" disappears small, thicken it.
