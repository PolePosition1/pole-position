# Color

Pole Position lives on black. The palette is a **timing screen**: one signature
color that means *the best* (purple), three signals that read instantly (green =
correct, red = the model / lock / DNF, amber = closing), and a disciplined
neutral ramp. If a fourth "fun" color is ever tempting, the answer is no.

## The signature: Purple Sector
In F1 timing, **purple = fastest, the best, the benchmark.** That is the whole
idea of Pole Position. Purple `#9B2FFF` is the primary brand color and the only
color allowed to carry the brand on its own — CTAs, the active/winner state, the
"you beat the model" moment, focus rings, the glow.

## Palette

### Surfaces
| Token | Hex | Use |
|---|---|---|
| Lights Out | `#0A0E17` | Primary background. The pre-start black. |
| Carbon | `#14181F` | Cards, sheets, nav — one step up from the floor. |
| Pit Wall | `#1E242E` | Inputs, hover fills, secondary surfaces. |
| Line | `#2A3340` | Borders, dividers, hairlines. |

### Purple (signature)
| Token | Hex | Use |
|---|---|---|
| Purple 200 | `#D9B8FF` | Links & brand text **on dark** (small sizes). |
| Purple 400 | `#B47CFF` | Hover text, secondary accents. |
| Purple 500 | `#9B2FFF` | **Primary.** Button fills, winner state, the glow. |
| Purple 700 | `#7A1FCC` | Pressed / hover on purple fills. |
| Purple 900 | `#3D0F66` | Subtle tinted background fills, chips. |

### Signals
| Token | Hex | Means |
|---|---|---|
| Go Green 500 | `#00E676` | Correct pick. Leaderboard climb. "Lights out, away we go." |
| Pole Red 500 | `#FF2436` | The model (antagonist). Lock-in. DNF. Wrong pick. **Sparingly.** |
| Amber 500 | `#FFB800` | Picks closing. Pending. Caution. |

Each signal has `400` (text-on-dark) and `700` (pressed) variants — see `tokens.css`.

### Text
| Token | Hex | Use | Min size |
|---|---|---|---|
| Primary | `#FFFFFF` | Headlines, key numbers | any |
| Secondary (Ghost) | `#E8EAED` | Body copy | any |
| Muted | `#9AA3AF` | Captions, secondary copy | any |
| Faint | `#5A626E` | Labels, disabled | **18px+ only** (fails AA at body size) |

### Gradients
- **Pole** `linear-gradient(135deg,#9B2FFF→#2D7FFF)` — hero surfaces, primary CTA fills, key moments. The electric-blue endpoint exists **only** inside this gradient and as link-hover; never as a standalone fill.
- **Podium** `linear-gradient(135deg,#FFB800→#FF2436)` — win/podium celebration only.

## Contrast rules (non-negotiable)
- Body text is **Ghost `#E8EAED` or Muted `#9AA3AF`** on Lights Out — both clear AA.
- Purple `#9B2FFF` is a **heading / CTA / accent** color, not a small-body-text color on black. For purple text on dark at body size, use **Purple 200 `#D9B8FF`**.
- Purple buttons: fill `#9B2FFF`, label **white, bold, ≥16px**. Hover `#7A1FCC`.
- Never put Pole Red and Go Green as the only differentiator side by side without a shape/label too (colorblind safety) — pair red with a lock icon, green with a check.

## The 60 / 30 / 10
- **60%** Lights Out + Carbon (the black canvas).
- **30%** text + Line + neutral UI.
- **10%** Purple (and only a flash of green/red/amber as signals).
Purple should feel *earned*. When everything glows, nothing does.
