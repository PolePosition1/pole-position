# Result Card (shareable)
The post-race "here's how I did vs the model" card users share.

- Canvas: 1080x1350 (IG portrait) on Lights Out `#0A0E17`.
- Header: Pole Position wordmark (white) + race name (Saira 800 caps).
- Body: user score vs model score, mono tabular, big (data-xl). Winner side gets purple glow.
- Per-category breakdown rows (mono): P1 / Podium / Pole / FL — check (green) or miss (faint).
- If user beat the model: "CALLED IT" stamp (purple gradient).
- Footer: @polepositionapp + WhatsApp/community CTA. No driver/team imagery.
